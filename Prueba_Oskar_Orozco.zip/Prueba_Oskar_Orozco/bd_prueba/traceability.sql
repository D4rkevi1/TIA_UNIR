CREATE TABLE traceability
(
traceabilityId BIGSERIAL PRIMARY KEY,
searchId       BIGINT    REFERENCES search (searchId) NOT NULL,
searchDate     TIMESTAMP
);