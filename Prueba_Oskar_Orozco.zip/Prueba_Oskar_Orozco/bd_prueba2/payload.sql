CREATE TABLE payload
(
payloadId   BIGSERIAL PRIMARY KEY,
searchId    BIGINT,
hotelId     VARCHAR(50),
checkIn     TIMESTAMP,
checkOut    TIMESTAMP,
ages        VARCHAR(100),
countSearch BIGINT,
payloadDate TIMESTAMP
);
