package com.proyecto.consumidor.domain.service;

import com.proyecto.consumidor.domain.model.RequestConsumerModel;
import com.proyecto.consumidor.domain.port.api.IConsumerApiPort;
import com.proyecto.consumidor.domain.port.spi.IConsumerSpiPort;
import org.springframework.stereotype.Service;

@Service
public class PrincipalServiceDomain implements IConsumerApiPort {
    private final IConsumerSpiPort iConsumerSpiPort;

    public PrincipalServiceDomain(IConsumerSpiPort iConsumerSpiPort) {
        this.iConsumerSpiPort = iConsumerSpiPort;
    }

    @Override
    public void consumerServiceDomain(RequestConsumerModel requestConsumerModel) {
        iConsumerSpiPort.savePayload(requestConsumerModel);
    }
}
