package com.proyecto.consumidor.infrastructure.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;

import java.util.Date;

@Entity
@Table(name = "payload")
public class PayloadEntity {
    @Id
    @Column(name = "payloadid", unique = true, updatable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer payloadId;

    @Column(name = "searchid")
    private Integer searchId;

    @Column(name = "hotelid")
    private String hotelId;

    @Column(name = "checkin")
    private Date checkIn;

    @Column(name = "checkout")
    private Date checkOut;

    @Column(name = "ages")
    private String ages;

    @Column(name = "countsearch")
    private Integer countSearch;

    @CreationTimestamp
    @Column(name = "payloaddate")
    private Date payloadDate;

    public Integer getPayloadId() {
        return payloadId;
    }

    public void setPayloadId(Integer payloadId) {
        this.payloadId = payloadId;
    }

    public Integer getSearchId() {
        return searchId;
    }

    public void setSearchId(Integer searchId) {
        this.searchId = searchId;
    }

    public String getHotelId() {
        return hotelId;
    }

    public void setHotelId(String hotelId) {
        this.hotelId = hotelId;
    }

    public Date getCheckIn() {
        return checkIn;
    }

    public void setCheckIn(Date checkIn) {
        this.checkIn = checkIn;
    }

    public Date getCheckOut() {
        return checkOut;
    }

    public void setCheckOut(Date checkOut) {
        this.checkOut = checkOut;
    }

    public String getAges() {
        return ages;
    }

    public void setAges(String ages) {
        this.ages = ages;
    }

    public Integer getCountSearch() {
        return countSearch;
    }

    public void setCountSearch(Integer countSearch) {
        this.countSearch = countSearch;
    }

    public Date getPayloadDate() {
        return payloadDate;
    }

    public void setPayloadDate(Date payloadDate) {
        this.payloadDate = payloadDate;
    }
}
