package com.proyecto.consumidor.application.service;

import org.springframework.kafka.support.Acknowledgment;

public interface IPrincipalConsumer {
    void inboundNotification(String data);
}
