package com.proyecto.consumidor.domain.port.api;

import com.proyecto.consumidor.domain.model.RequestConsumerModel;

public interface IConsumerApiPort {
    void consumerServiceDomain(RequestConsumerModel requestConsumerModel);
}
