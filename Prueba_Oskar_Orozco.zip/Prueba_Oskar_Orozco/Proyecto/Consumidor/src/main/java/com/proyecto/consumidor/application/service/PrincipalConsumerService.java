package com.proyecto.consumidor.application.service;

import com.google.gson.Gson;
import com.proyecto.consumidor.application.mapper.NotificationFields;
import com.proyecto.consumidor.domain.model.RequestConsumerModel;
import com.proyecto.consumidor.domain.port.api.IConsumerApiPort;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

@Service
public class PrincipalConsumerService implements IPrincipalConsumer{
    private final IConsumerApiPort iConsumerApiPort;

    public PrincipalConsumerService(IConsumerApiPort iConsumerApiPort) {
        this.iConsumerApiPort = iConsumerApiPort;
    }

    @Override
    public void inboundNotification(String data) {
        NotificationFields notificationFields = new Gson().fromJson(data, NotificationFields.class);
        iConsumerApiPort.consumerServiceDomain(mapperToRequestConsumerModel(notificationFields));
    }

    private RequestConsumerModel mapperToRequestConsumerModel(NotificationFields notificationFields){
        Integer payloadId = null;
        Integer searchId = notificationFields.getSearchId();
        String hotelId = notificationFields.getSearch().getHotelId();
        Date checkIn = fromStringToDate(notificationFields.getSearch().getCheckIn(), "dd/MM/yyyy");
        Date checkOut = fromStringToDate(notificationFields.getSearch().getCheckOut(), "dd/MM/yyyy");
        String ages = notificationFields.getSearch().getAges();
        Integer count = notificationFields.getCount();

        return new RequestConsumerModel(payloadId, searchId, hotelId, checkIn, checkOut, ages, count);
    }

    private Date fromStringToDate(String date, String formatDateIn){
        try{
            DateFormat dateFormat = new SimpleDateFormat((formatDateIn));
            return dateFormat.parse(date);
        }catch(Exception exception){
            throw new RuntimeException();
        }
    }
}
