package com.proyecto.consumidor.domain.port.spi;

import com.proyecto.consumidor.domain.model.RequestConsumerModel;

public interface IConsumerSpiPort {
    void savePayload(RequestConsumerModel requestConsumerModel);
}
