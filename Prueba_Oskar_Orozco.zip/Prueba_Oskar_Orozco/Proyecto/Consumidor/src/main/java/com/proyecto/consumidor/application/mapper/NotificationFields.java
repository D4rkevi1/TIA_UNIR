package com.proyecto.consumidor.application.mapper;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.proyecto.consumidor.application.dto.SearchDto;

public class NotificationFields {
    @JsonProperty("searchId")
    private final Integer searchId;
    @JsonProperty("search")
    private final SearchDto search;
    @JsonProperty("count")
    private final Integer count;

    public NotificationFields(Integer searchId, SearchDto search, Integer count) {
        this.searchId = searchId;
        this.search = search;
        this.count = count;
    }

    public Integer getSearchId() {
        return searchId;
    }

    public SearchDto getSearch() {
        return search;
    }

    public Integer getCount() {
        return count;
    }
}
