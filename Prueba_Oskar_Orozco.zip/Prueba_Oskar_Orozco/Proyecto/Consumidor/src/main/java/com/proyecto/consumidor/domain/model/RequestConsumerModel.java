package com.proyecto.consumidor.domain.model;

import java.util.Date;

public class RequestConsumerModel {
    private final Integer payloadId;
    private final Integer searchId;
    private final String hotelId;
    private final Date checkIn;
    private final Date checkOut;
    private final String ages;
    private final Integer countSearch;

    public RequestConsumerModel(Integer payloadId, Integer searchId, String hotelId, Date checkIn, Date checkOut, String ages, Integer countSearch) {
        this.payloadId = payloadId;
        this.searchId = searchId;
        this.hotelId = hotelId;
        this.checkIn = checkIn;
        this.checkOut = checkOut;
        this.ages = ages;
        this.countSearch = countSearch;
    }

    public Integer getPayloadId() {
        return payloadId;
    }

    public Integer getSearchId() {
        return searchId;
    }

    public String getHotelId() {
        return hotelId;
    }

    public Date getCheckIn() {
        return checkIn;
    }

    public Date getCheckOut() {
        return checkOut;
    }

    public String getAges() {
        return ages;
    }

    public Integer getCountSearch() {
        return countSearch;
    }
}
