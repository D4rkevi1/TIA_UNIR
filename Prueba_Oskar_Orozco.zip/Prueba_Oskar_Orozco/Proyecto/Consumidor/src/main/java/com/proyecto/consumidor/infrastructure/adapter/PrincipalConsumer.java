package com.proyecto.consumidor.infrastructure.adapter;

import com.proyecto.consumidor.application.service.IPrincipalConsumer;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

@Component
public class PrincipalConsumer {
    private final IPrincipalConsumer iPrincipalConsumer;

    public PrincipalConsumer(IPrincipalConsumer iPrincipalConsumer) {
        this.iPrincipalConsumer = iPrincipalConsumer;
    }

    @KafkaListener(topics = "${spring.kafka.topics}")
    public void listenerNotifications(@Payload String data, @Header(KafkaHeaders.OFFSET) String offset, Acknowledgment acknowledgment){
        iPrincipalConsumer.inboundNotification(data);
        acknowledgment.acknowledge();
    }
}
