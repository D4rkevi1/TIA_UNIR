package com.proyecto.consumidor.infrastructure.mapper;

import com.proyecto.consumidor.domain.model.RequestConsumerModel;
import com.proyecto.consumidor.infrastructure.entity.PayloadEntity;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, componentModel = "spring")
public interface IPayloadMapper {
    PayloadEntity toPayloadEntity(RequestConsumerModel requestConsumerModel);
}
