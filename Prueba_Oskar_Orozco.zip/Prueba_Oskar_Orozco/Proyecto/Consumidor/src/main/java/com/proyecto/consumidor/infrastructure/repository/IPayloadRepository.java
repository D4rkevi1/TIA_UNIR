package com.proyecto.consumidor.infrastructure.repository;

import com.proyecto.consumidor.infrastructure.entity.PayloadEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IPayloadRepository extends JpaRepository<PayloadEntity, Integer> {
}
