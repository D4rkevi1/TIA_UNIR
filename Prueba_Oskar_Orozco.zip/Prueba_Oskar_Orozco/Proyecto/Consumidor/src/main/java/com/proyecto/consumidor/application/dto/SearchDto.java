package com.proyecto.consumidor.application.dto;

public class SearchDto {
    private final String hotelId;
    private final String checkIn;
    private final String checkOut;
    private final String ages;

    public SearchDto(String hotelId, String checkIn, String checkOut, String ages) {
        this.hotelId = hotelId;
        this.checkIn = checkIn;
        this.checkOut = checkOut;
        this.ages = ages;
    }

    public String getHotelId() {
        return hotelId;
    }

    public String getCheckIn() {
        return checkIn;
    }

    public String getCheckOut() {
        return checkOut;
    }

    public String getAges() {
        return ages;
    }
}
