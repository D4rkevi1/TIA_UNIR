package com.proyecto.consumidor.infrastructure.dao;

import com.proyecto.consumidor.domain.model.RequestConsumerModel;
import com.proyecto.consumidor.domain.port.spi.IConsumerSpiPort;
import com.proyecto.consumidor.infrastructure.mapper.IPayloadMapper;
import com.proyecto.consumidor.infrastructure.repository.IPayloadRepository;
import org.springframework.stereotype.Service;

@Service
public class PrincipalConsumerDao implements IConsumerSpiPort {
    private final IPayloadRepository iPayloadRepository;
    private final IPayloadMapper iPayloadMapper;

    public PrincipalConsumerDao(IPayloadRepository iPayloadRepository, IPayloadMapper iPayloadMapper) {
        this.iPayloadRepository = iPayloadRepository;
        this.iPayloadMapper = iPayloadMapper;
    }

    @Override
    public void savePayload(RequestConsumerModel requestConsumerModel) {
        iPayloadRepository.save(iPayloadMapper.toPayloadEntity(requestConsumerModel));
    }
}
