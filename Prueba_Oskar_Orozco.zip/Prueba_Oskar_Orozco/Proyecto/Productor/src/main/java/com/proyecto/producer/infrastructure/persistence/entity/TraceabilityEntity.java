package com.proyecto.producer.infrastructure.persistence.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;

import java.util.Date;

@Entity
@Table(name = "traceability")
public class TraceabilityEntity {
    @Id
    @Column(name = "traceabilityid", unique = true, updatable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer traceabilityId;

    @Column(name = "searchid")
    private Integer searchId;

    @CreationTimestamp
    @Column(name = "searchdate")
    private Date searchDate;

    public Integer getTraceabilityId() {
        return traceabilityId;
    }

    public void setTraceabilityId(Integer traceabilityId) {
        this.traceabilityId = traceabilityId;
    }

    public Integer getSearchId() {
        return searchId;
    }

    public void setSearchId(Integer searchId) {
        this.searchId = searchId;
    }

    public Date getSearchDate() {
        return searchDate;
    }

    public void setSearchDate(Date searchDate) {
        this.searchDate = searchDate;
    }
}
