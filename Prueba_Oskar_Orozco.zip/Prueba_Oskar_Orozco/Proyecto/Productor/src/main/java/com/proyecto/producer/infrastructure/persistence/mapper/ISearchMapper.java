package com.proyecto.producer.infrastructure.persistence.mapper;

import com.proyecto.producer.domain.model.SearchModel;
import com.proyecto.producer.domain.model.SearchRequestModel;
import com.proyecto.producer.infrastructure.persistence.entity.SearchEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.ReportingPolicy;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, componentModel = "spring")
public interface ISearchMapper {
    @Mappings({
            @Mapping(ignore = true, target = "ages"),
            @Mapping(source = "searchRequestModel.checkIn",
                     target = "checkIn",
                     dateFormat = "dd/MM/yyyy"),
            @Mapping(source = "searchRequestModel.checkOut",
                    target = "checkOut",
                    dateFormat = "dd/MM/yyyy")
    })
    SearchEntity toSearchEntity(SearchRequestModel searchRequestModel);
    @Mapping(ignore = true, target = "ages")
    SearchRequestModel toSearchRequestModel(SearchEntity searchEntity);

    SearchModel toSearchModel(SearchEntity searchEntity);
}
