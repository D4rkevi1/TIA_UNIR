package com.proyecto.producer.infrastructure.constant;

public class KafkaConstant {
    public static final String TOPIC_NAME = "hotel_availability_searches";
    public static final int PARTITION_COUNT = 2;
    public static final int REPLICA_COUNT = 2;
    public static final String RETENTION_MS = "86400000";
    public static final String SEGMENT_BYTES = "1073741824";
    public static final String MAX_MESSAGE_BYTES = "1048576";
}
