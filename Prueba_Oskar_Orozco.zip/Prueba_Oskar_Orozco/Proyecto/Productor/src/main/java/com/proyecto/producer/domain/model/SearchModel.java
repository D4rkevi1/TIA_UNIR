package com.proyecto.producer.domain.model;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;

public class SearchModel {
    private final String hotelId;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
    private final Date checkIn;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
    private final Date checkOut;
    private final String ages;

    public SearchModel(String hotelId, Date checkIn, Date checkOut, String ages) {
        this.hotelId = hotelId;
        this.checkIn = checkIn;
        this.checkOut = checkOut;
        this.ages = ages;
    }

    public String getHotelId() {
        return hotelId;
    }

    public Date getCheckIn() {
        return checkIn;
    }

    public Date getCheckOut() {
        return checkOut;
    }

    public String getAges() {
        return ages;
    }
}
