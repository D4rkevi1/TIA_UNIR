package com.proyecto.producer.domain.port.spi;

import com.proyecto.producer.domain.model.SearchModel;
import com.proyecto.producer.domain.model.SearchRequestModel;
import com.proyecto.producer.domain.model.SearchResponseModel;
import com.proyecto.producer.domain.model.TraceabilityModel;

public interface IPrincipalSpiPort {
    SearchResponseModel saveSearch(SearchRequestModel searchRequestModel);
    void saveTraceability(TraceabilityModel traceabilityModel);
    Integer getCount(Integer searchId);
    SearchModel getSearch(Integer searchId);
}
