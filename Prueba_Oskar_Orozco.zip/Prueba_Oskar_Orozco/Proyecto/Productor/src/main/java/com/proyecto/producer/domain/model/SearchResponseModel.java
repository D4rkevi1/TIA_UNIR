package com.proyecto.producer.domain.model;

public class SearchResponseModel {
    private final Integer searchId;

    public SearchResponseModel(Integer searchId) {
        this.searchId = searchId;
    }

    public Integer getSearchId() {
        return searchId;
    }
}
