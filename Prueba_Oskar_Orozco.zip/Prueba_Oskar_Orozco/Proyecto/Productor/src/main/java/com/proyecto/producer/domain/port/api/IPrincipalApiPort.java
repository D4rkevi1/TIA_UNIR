package com.proyecto.producer.domain.port.api;

import com.proyecto.producer.domain.model.CountResponseModel;
import com.proyecto.producer.domain.model.SearchRequestModel;
import com.proyecto.producer.domain.model.SearchResponseModel;

public interface IPrincipalApiPort {
    SearchResponseModel saveSearch(SearchRequestModel searchRequestModel, String topicName);
    CountResponseModel getCount(Integer searchId);
}
