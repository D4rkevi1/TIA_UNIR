package com.proyecto.producer.application.service;

import com.proyecto.producer.domain.model.CountResponseModel;
import com.proyecto.producer.domain.model.SearchRequestModel;
import com.proyecto.producer.domain.model.SearchResponseModel;

public interface IPrincipalAplicationService {
    SearchResponseModel saveSearch(SearchRequestModel searchRequestModel);
    CountResponseModel getCount(Integer searchId);
}
