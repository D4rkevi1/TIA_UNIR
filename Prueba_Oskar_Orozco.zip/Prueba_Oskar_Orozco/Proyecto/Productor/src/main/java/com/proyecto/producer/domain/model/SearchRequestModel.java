package com.proyecto.producer.domain.model;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;

public class SearchRequestModel {
    private final Integer searchId;
    private final String hotelId;
    private final String checkIn;
    private final String checkOut;
    private final Object[] ages;

    public SearchRequestModel(Integer searchId, String hotelId, String checkIn, String checkOut, Object[] ages) {
        this.searchId = searchId;
        this.hotelId = hotelId;
        this.checkIn = checkIn;
        this.checkOut = checkOut;
        this.ages = ages;
    }

    public Integer getSearchId() {
        return searchId;
    }

    public String getHotelId() {
        return hotelId;
    }

    public String getCheckIn() {
        return checkIn;
    }

    public String getCheckOut() {
        return checkOut;
    }

    public Object[] getAges() {
        return ages;
    }
}
