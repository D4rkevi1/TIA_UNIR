package com.proyecto.producer.infrastructure.constant;

public class PrincipalConstant {
    public static final String SEARCH = "/search";
    public static final String COUNT = "/count/{searchId}";
}
