package com.proyecto.producer.infrastructure.config;

import com.proyecto.producer.infrastructure.constant.KafkaConstant;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.common.config.TopicConfig;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.TopicBuilder;

import java.util.HashMap;
import java.util.Map;

@Configuration
public class KafkaTopicConfig {
    @Bean
    public NewTopic generateTopic(){
        Map<String, String> configurations = new HashMap<>();
        configurations.put(TopicConfig.CLEANUP_POLICY_CONFIG, TopicConfig.CLEANUP_POLICY_COMPACT);
        configurations.put(TopicConfig.RETENTION_MS_CONFIG, KafkaConstant.RETENTION_MS);
        configurations.put(TopicConfig.SEGMENT_BYTES_CONFIG, KafkaConstant.SEGMENT_BYTES);
        configurations.put(TopicConfig.MAX_MESSAGE_BYTES_CONFIG, KafkaConstant.MAX_MESSAGE_BYTES);

        return TopicBuilder.name(KafkaConstant.TOPIC_NAME)
                .partitions(KafkaConstant.PARTITION_COUNT)
                .replicas(KafkaConstant.REPLICA_COUNT)
                .configs(configurations)
                .build();
    }
}
