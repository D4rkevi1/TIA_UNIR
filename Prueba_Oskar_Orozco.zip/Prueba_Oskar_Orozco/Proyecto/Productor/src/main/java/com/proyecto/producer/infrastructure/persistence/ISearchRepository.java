package com.proyecto.producer.infrastructure.persistence;

import com.proyecto.producer.infrastructure.persistence.entity.SearchEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;

@Repository
public interface ISearchRepository extends JpaRepository<SearchEntity, Integer> {
    @Query(value = "SELECT MAX(searchid) FROM search " +
            "WHERE hotelid = :hotelId " +
            "  AND checkin = :checkIn " +
            "  AND checkout = :checkOut " +
            "  AND ages = :ages", nativeQuery = true)
    Integer oldSearch(@Param("hotelId") String hotelId,
                      @Param("checkIn") Date checkIn,
                      @Param("checkOut") Date checkOut,
                      @Param("ages") String ages);

    SearchEntity findBySearchId(Integer searchId);
}
