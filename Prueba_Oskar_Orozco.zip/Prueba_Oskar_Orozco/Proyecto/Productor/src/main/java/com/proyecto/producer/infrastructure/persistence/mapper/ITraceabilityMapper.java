package com.proyecto.producer.infrastructure.persistence.mapper;

import com.proyecto.producer.domain.model.TraceabilityModel;
import com.proyecto.producer.infrastructure.persistence.entity.TraceabilityEntity;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, componentModel = "spring")
public interface ITraceabilityMapper {
    TraceabilityEntity toTraceabilityEntity(TraceabilityModel traceabilityModel);
}
