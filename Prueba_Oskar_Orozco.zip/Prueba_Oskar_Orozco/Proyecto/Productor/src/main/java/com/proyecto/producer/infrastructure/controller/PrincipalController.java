package com.proyecto.producer.infrastructure.controller;

import com.proyecto.producer.infrastructure.constant.PrincipalConstant;
import com.proyecto.producer.application.service.IPrincipalAplicationService;
import com.proyecto.producer.domain.model.CountResponseModel;
import com.proyecto.producer.domain.model.SearchRequestModel;
import com.proyecto.producer.domain.model.SearchResponseModel;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping
public class PrincipalController {
    private final IPrincipalAplicationService iPrincipalAplicationService;

    public PrincipalController(IPrincipalAplicationService iPrincipalAplicationService) {
        this.iPrincipalAplicationService = iPrincipalAplicationService;
    }

    @PostMapping(PrincipalConstant.SEARCH)
    public ResponseEntity<SearchResponseModel> search(@RequestBody SearchRequestModel searchRequestModel){
        return ResponseEntity.ok(iPrincipalAplicationService.saveSearch(searchRequestModel));
    }

    @GetMapping(PrincipalConstant.COUNT)
    public ResponseEntity<CountResponseModel> count(@PathVariable Integer searchId) {
        return ResponseEntity.ok(iPrincipalAplicationService.getCount(searchId));
    }
}
