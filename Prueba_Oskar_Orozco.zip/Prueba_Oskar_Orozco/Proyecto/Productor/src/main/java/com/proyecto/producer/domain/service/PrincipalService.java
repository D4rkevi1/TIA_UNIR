package com.proyecto.producer.domain.service;

import com.proyecto.producer.domain.model.*;
import com.proyecto.producer.domain.port.api.IPrincipalApiPort;
import com.proyecto.producer.domain.port.spi.IPrincipalSpiPort;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class PrincipalService implements IPrincipalApiPort {
    private final IPrincipalSpiPort iPrincipalSpiPort;
    private final KafkaTemplate<String, CountResponseModel> kafkaTemplate;

    public PrincipalService(IPrincipalSpiPort iPrincipalSpiPort, KafkaTemplate<String, CountResponseModel> kafkaTemplate) {
        this.iPrincipalSpiPort = iPrincipalSpiPort;
        this.kafkaTemplate = kafkaTemplate;
    }

    @Override
    public SearchResponseModel saveSearch(SearchRequestModel searchRequestModel, String topicName){
        SearchResponseModel searchResponseModel;
        searchResponseModel = iPrincipalSpiPort.saveSearch(searchRequestModel);

        TraceabilityModel traceabilityModel = new TraceabilityModel(null, searchResponseModel.getSearchId(), null);
        iPrincipalSpiPort.saveTraceability(traceabilityModel);
        sendNotification(searchResponseModel.getSearchId(), topicName);
        return searchResponseModel;
    }

    @Override
    public CountResponseModel getCount(Integer searchId) {
        Integer count = iPrincipalSpiPort.getCount(searchId);
        return mapperToCountResponseModel(searchId, iPrincipalSpiPort.getSearch(searchId), count);
    }

    public CountResponseModel mapperToCountResponseModel(Integer searchId, SearchModel searchModel, Integer count){
        return new CountResponseModel(searchId, searchModel, count);
    }

    public void  sendNotification(Integer searchId, String topicName){
        CountResponseModel countResponseModel = getCount(searchId);
        kafkaTemplate.send(topicName, countResponseModel);
    }
}
