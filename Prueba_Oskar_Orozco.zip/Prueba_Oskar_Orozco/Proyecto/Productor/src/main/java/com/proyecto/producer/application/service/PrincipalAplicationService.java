package com.proyecto.producer.application.service;

import com.proyecto.producer.infrastructure.constant.KafkaConstant;
import com.proyecto.producer.domain.model.CountResponseModel;
import com.proyecto.producer.domain.model.SearchRequestModel;
import com.proyecto.producer.domain.model.SearchResponseModel;
import com.proyecto.producer.domain.port.api.IPrincipalApiPort;
import org.springframework.stereotype.Service;

@Service
public class PrincipalAplicationService implements IPrincipalAplicationService{
    private final IPrincipalApiPort iPrincipalApiPort;

    public PrincipalAplicationService(IPrincipalApiPort iPrincipalApiPort) {
        this.iPrincipalApiPort = iPrincipalApiPort;
    }

    @Override
    public SearchResponseModel saveSearch(SearchRequestModel searchRequestModel) {
        return iPrincipalApiPort.saveSearch(searchRequestModel, KafkaConstant.TOPIC_NAME);
    }

    @Override
    public CountResponseModel getCount(Integer searchId) {
        return iPrincipalApiPort.getCount(searchId);
    }
}
