package com.proyecto.producer.domain.model;

public class CountResponseModel {
    private final Integer searchId;
    private final SearchModel search;
    private final Integer count;

    public CountResponseModel(Integer searchId, SearchModel search, Integer count) {
        this.searchId = searchId;
        this.search = search;
        this.count = count;
    }

    public Integer getSearchId() {
        return searchId;
    }

    public SearchModel getSearch() {
        return search;
    }

    public Integer getCount() {
        return count;
    }
}
