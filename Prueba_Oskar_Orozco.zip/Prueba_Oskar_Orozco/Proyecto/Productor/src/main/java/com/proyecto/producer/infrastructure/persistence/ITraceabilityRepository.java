package com.proyecto.producer.infrastructure.persistence;

import com.proyecto.producer.infrastructure.persistence.entity.TraceabilityEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ITraceabilityRepository extends JpaRepository<TraceabilityEntity, Integer> {
    Integer countBySearchId(Integer searchId);
}
