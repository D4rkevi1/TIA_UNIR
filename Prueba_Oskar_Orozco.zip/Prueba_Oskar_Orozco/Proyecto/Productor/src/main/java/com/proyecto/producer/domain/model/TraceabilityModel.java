package com.proyecto.producer.domain.model;

import java.util.Date;

public class TraceabilityModel {
    private final Integer traceabilityId;
    private final Integer searchId;
    private final Date searchDate;

    public TraceabilityModel(Integer traceabilityId, Integer searchId, Date searchDate) {
        this.traceabilityId = traceabilityId;
        this.searchId = searchId;
        this.searchDate = searchDate;
    }

    public Integer getTraceabilityId() {
        return traceabilityId;
    }

    public Integer getSearchId() {
        return searchId;
    }

    public Date getSearchDate() {
        return searchDate;
    }
}
