package com.proyecto.producer.infrastructure.persistence.dao;

import com.proyecto.producer.domain.model.SearchModel;
import com.proyecto.producer.domain.model.SearchRequestModel;
import com.proyecto.producer.domain.model.SearchResponseModel;
import com.proyecto.producer.domain.model.TraceabilityModel;
import com.proyecto.producer.domain.port.spi.IPrincipalSpiPort;
import com.proyecto.producer.infrastructure.persistence.entity.SearchEntity;
import com.proyecto.producer.infrastructure.persistence.mapper.ISearchMapper;
import com.proyecto.producer.infrastructure.persistence.mapper.ITraceabilityMapper;
import com.proyecto.producer.infrastructure.persistence.ISearchRepository;
import com.proyecto.producer.infrastructure.persistence.ITraceabilityRepository;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

@Service
public class PrincipalDao implements IPrincipalSpiPort {
    private final ISearchRepository iSearchRepository;
    private final ITraceabilityRepository iTraceabilityRepository;
    private final ISearchMapper iSearchMapper;
    private final ITraceabilityMapper iTraceabilityMapper;

    public PrincipalDao(ISearchRepository iSearchRepository, ITraceabilityRepository iTraceabilityRepository, ISearchMapper iSearchMapper, ITraceabilityMapper iTraceabilityMapper) {
        this.iSearchRepository = iSearchRepository;
        this.iTraceabilityRepository = iTraceabilityRepository;
        this.iSearchMapper = iSearchMapper;
        this.iTraceabilityMapper = iTraceabilityMapper;
    }

    @Override
    public SearchResponseModel saveSearch(SearchRequestModel searchRequestModel) {
        SearchEntity searchEntity = iSearchMapper.toSearchEntity(searchRequestModel);
        searchEntity.setAges(objectToString(searchRequestModel.getAges()));
        Integer searchId = iSearchRepository.oldSearch(searchEntity.getHotelId(), searchEntity.getCheckIn(), searchEntity.getCheckOut(), searchEntity.getAges());

        if(searchId == null){
            searchRequestModel = iSearchMapper.toSearchRequestModel(iSearchRepository.save(searchEntity));
            searchId = searchRequestModel.getSearchId();
        }
        return new SearchResponseModel(searchId);
    }

    @Override
    public void saveTraceability(TraceabilityModel traceabilityModel) {
        iTraceabilityRepository.save(iTraceabilityMapper.toTraceabilityEntity(traceabilityModel));
    }

    @Override
    public Integer getCount(Integer searchId) {
        return iTraceabilityRepository.countBySearchId(searchId);
    }

    @Override
    public SearchModel getSearch(Integer searchId) {
        return iSearchMapper.toSearchModel(iSearchRepository.findBySearchId(searchId));
    }

    private String objectToString(Object[] object){
        final StringBuilder builder = new StringBuilder();
        List<Object> listObject = Arrays.stream(object).sorted().toList();
        listObject.forEach(lst -> {
            builder.append(lst + ", ");
        });
        String ages = "[" + builder.substring(0, builder.length() - 2) + "]";
        return ages;
    }
}
