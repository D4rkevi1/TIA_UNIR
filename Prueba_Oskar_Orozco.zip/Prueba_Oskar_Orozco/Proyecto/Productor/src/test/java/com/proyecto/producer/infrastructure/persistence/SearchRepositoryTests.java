package com.proyecto.producer.infrastructure.persistence;

import com.proyecto.producer.infrastructure.persistence.entity.SearchEntity;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(SpringExtension.class)
@SpringBootTest
public class SearchRepositoryTests {
    private final ISearchRepository iSearchRepository;

    public SearchRepositoryTests(ISearchRepository iSearchRepository) {
        this.iSearchRepository = iSearchRepository;
    }

    @DisplayName("Prueba consulta search por searchId")
    @Test
    public void testFindBySearchId(){
        SearchEntity searchEntity = iSearchRepository.findBySearchId(22);
        assertThat(searchEntity).isNotNull();
        assertThat(searchEntity.getSearchId()).isGreaterThan(0);
    }
}
