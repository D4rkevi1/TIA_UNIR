package com.proyecto.producer.infrastructure.persistence;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(SpringExtension.class)
@SpringBootTest
public class TraceabilityRepositoryTests {
    private final ITraceabilityRepository findBySearchId;

    public TraceabilityRepositoryTests(ITraceabilityRepository findBySearchId) {
        this.findBySearchId = findBySearchId;
    }

    @DisplayName("Prueba consulta traceability por searchId")
    @Test
    public void testGetCount(){
        Integer count = findBySearchId.countBySearchId(22);
        assertThat(count).isNotNull();
        assertThat(count).isGreaterThan(0);
    }
}
